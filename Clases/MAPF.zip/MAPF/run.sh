#!/bin/sh
clingo bodegas.lp | python3 process.py > config.js
